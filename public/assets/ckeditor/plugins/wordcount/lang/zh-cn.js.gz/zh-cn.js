/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('wordcount', 'zh-cn', {
    WordCount: '词数:',
    CharCount: '字符:',
    CharCountWithHTML: '字符 (含HTML)',
    Paragraphs: '段落:',
    pasteWarning: '由于上限允许,内容不能粘贴',
    Selected: '已选择: ',
    title: '统计'
});
